//
//  OCTTeam.h
//  OctoKit
//
//  Created by Josh Abernathy on 3/28/12.
//  Copyright (c) 2012 GitHub. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OCTEntity.h"

// Represents a team within an OCTOrganization.
@interface OCTTeam : OCTEntity
@end
